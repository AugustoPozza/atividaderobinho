<?php

class Banco {
    private $usuario;
    private $senha;
    private $servidor;
    private $porta;
    private $nome_banco;
    private $pdo;

    public function __construct() {
        $this->usuario = "root";
        $this->senha = "";
        $this->servidor = "localhost";
        $this->porta = "3306";
        $this->nome_banco = "teste2";
        try {
            $this->pdo = new PDO("mysql:host={$this->servidor};port={$this->porta};dbname={$this->nome_banco}", $this->usuario, $this->senha);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die('Connection failed: ' . $e->getMessage());
        }
    }

    public function getPdo() {
        return $this->pdo;
    }

    public function Consultar($sql) {
        $stm = $this->Excutar($sql);
        return $stm->fetchAll(PDO::FETCH_ASSOC);
    }

    public function Excutar($sql) {
        $stm = $this->pdo->prepare($sql);
        $stm->execute();
        return $stm;
    }
}
?>
