<?php
include 'db.php';

$sql = "SELECT * FROM usuarios";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        echo '<tr>
                <td>' . $row["id"] . '</td>
                <td>' . $row["nome"] . '</td>
                <td>' . $row["cpf"] . '</td>
                <td>' . $row["idade"] . '</td>
                <td>' . $row["estado"] . '</td>
                <td class="text-center">
                    <button type="button" class="btn btn-primary mr-2 edit-btn" data-id="' . $row["id"] . '">Editar</button>
                    <button type="button" class="btn btn-danger delete-btn" data-id="' . $row["id"] . '">Remover</button>
                </td>
              </tr>';
    }
} else {
    echo "<tr><td colspan='6' class='text-center'>No records found</td></tr>";
}

$conn->close();
?>
