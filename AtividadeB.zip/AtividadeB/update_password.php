<?php
require_once("banco.php");

$banco = new Banco();
$pdo = $banco->getPdo();

$email = 'robson.zambroti@unifil.br';
$plainPassword = '123456';
$hashedPassword = password_hash($plainPassword, PASSWORD_DEFAULT);

$sql = "UPDATE usuario SET senha = :senha WHERE email_login = :email_login";
$stm = $pdo->prepare($sql);
$stm->bindParam(':senha', $hashedPassword);
$stm->bindParam(':email_login', $email);
$stm->execute();

echo "Password updated successfully.";
?>
