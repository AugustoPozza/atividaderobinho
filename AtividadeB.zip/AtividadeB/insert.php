<?php
include 'db.php';

if (isset($_POST['nome']) && isset($_POST['cpf']) && isset($_POST['idade']) && isset($_POST['estado'])) {
    $nome = $_POST['nome'];
    $cpf = $_POST['cpf'];
    $idade = $_POST['idade'];
    $estado = $_POST['estado'];

    $sql = "INSERT INTO usuarios (nome, cpf, idade, estado) VALUES ('$nome', '$cpf', '$idade', '$estado')";
    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Required fields are missing.";
}

$conn->close();
?>
