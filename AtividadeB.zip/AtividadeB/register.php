<?php
require_once("banco.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['first_name'] . ' ' . $_POST['last_name'];
    $email = $_POST['email'];
    $senha = $_POST['password'];
    $hashedPassword = password_hash($senha, PASSWORD_DEFAULT);

    try {
        $banco = new Banco();
        $pdo = $banco->getPdo();
        $sql = "INSERT INTO usuario (nome, email_login, senha) VALUES (:nome, :email_login, :senha)";
        $stm = $pdo->prepare($sql);
        $stm->bindParam(':nome', $nome);
        $stm->bindParam(':email_login', $email);
        $stm->bindParam(':senha', $hashedPassword);
        $stm->execute();

        echo json_encode(["status" => "1", "msg" => "Account created successfully."]);
    } catch (PDOException $e) {
        echo json_encode(["status" => "0", "msg" => "Error: " . $e->getMessage()]);
    }
} else {
    echo json_encode(["status" => "0", "msg" => "Invalid request method."]);
}
?>
