<?php
include 'db.php';

$id = $_POST['id'];
$nome = $_POST['nome'];
$cpf = $_POST['cpf'];
$idade = $_POST['idade'];
$estado = $_POST['estado'];

$sql = "UPDATE usuarios SET nome='$nome', cpf='$cpf', idade='$idade', estado='$estado' WHERE id=$id";
if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
