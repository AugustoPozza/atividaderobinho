<?php
require_once("banco.php");

class Autenticacao {
    private $login;
    private $banco;

    public function __construct($login) {
        $this->login = $login;
        $this->banco = new Banco();
    }

    public function validaSenha($senha) {
        $pdo = $this->banco->getPdo();
        $sql = "SELECT senha FROM usuario WHERE email_login = :email_login";  // Update column name to 'email_login'
        $stm = $pdo->prepare($sql);
        $stm->bindParam(':email_login', $this->login);
        $stm->execute();
        $result = $stm->fetch(PDO::FETCH_ASSOC);

        if ($result && ($senha == $result['senha'])) {
            return true;
        } else {
            return false;
        }
    }

    public function tokenValido() {
        $pdo = $this->banco->getPdo();
        $sql = "SELECT token FROM tokens WHERE usuario = :usuario AND validade > NOW()";  // Update column name to 'email_login'
        $stm = $pdo->prepare($sql);
        $stm->bindParam(':usuario', $this->login);
        $stm->execute();
        $result = $stm->fetch(PDO::FETCH_ASSOC);

        return $result ? $result['token'] : null;
    }

    public function gerarToken() {
        $pdo = $this->banco->getPdo();
        $token = bin2hex(random_bytes(16));
        $sql = "INSERT INTO tokens (usuario, token, validade) VALUES (:usuario, :token, DATE_ADD(NOW(), INTERVAL 1 HOUR))";  // Update column name to 'email_login'
        $stm = $pdo->prepare($sql);
        $stm->bindParam(':usuario', $this->login);
        $stm->bindParam(':token', $token);
        $stm->execute();

        return $token;
    }
}
?>
