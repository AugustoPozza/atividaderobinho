<?php
date_default_timezone_set('America/Sao_Paulo');
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once("banco.php");
require_once("Autenticacao.php");

$_SESSION['token'] = null;
$email = $_POST['email'];
$password = $_POST['password'];

try {
    $Auth = new Autenticacao($email);
    if ($Auth->validaSenha($password)) {
        $token = $Auth->tokenValido();
        if ($token == null) {
            $token = $Auth->gerarToken();
        }
        $_SESSION['token'] = $token;
        $response = [
            "status" => "1",
            "msg" => "Login efetuado com sucesso!",
            "token" => $token
        ];
    } else {
        $response = [
            "status" => "0",
            "msg" => "Usuário ou senha inválido"
        ];
    }
} catch (Exception $e) {
    $response = [
        "status" => "0",
        "msg" => "Erro no servidor: " . $e->getMessage()
    ];
}

header('Content-Type: application/json');
echo json_encode($response);
?>
